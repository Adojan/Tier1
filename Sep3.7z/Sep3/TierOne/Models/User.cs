﻿using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text.Json.Serialization;

namespace TierOne.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Name { get; set; }

        public IList<User> Users { get; set; }

        public User(string username, string password, string name)
        {
            Username = username;
            Password = password;
            Name = name;
        }

        public User()
        {

        }

        public User(int id, string username, string password, string name, string phone, string address)
        {
            Username = username;
            Password = password;
            Name = name;
            Phone = phone;
            Address = address;


        }
    }
}