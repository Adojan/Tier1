﻿using System.Collections.Generic;
using static TierOne.Models.User;

namespace TierOne.Models
{
    public class Administrator
    {
        public int adminId { get; set; }
        public string username { get; set; }
        public string Name { get; set; }
        public string password { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        public IList<User> Users { get; set; }

        public Administrator(string username, string password, string name)
        {
            this.username = username;
            this.password = password;
            this.Name = name;
        }

        public Administrator()
        {

        }

        public Administrator(int id, string username, string password, string name, string address)
        {
            this.username = username;
            this.password= password;
            this.Name = name;
            this.Address = address;


        }
    }
}