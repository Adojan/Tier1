﻿using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text.Json.Serialization;

namespace TierOne.Models
{
    public class Item
    {
        public int Id { get; set; }
        public string itemName { get; set; }
        public string Description{ get; set; }
        public string Seller { get; set; }
        
        public IList<Item> Items { get; set; }

        public Item(int Id,string itemName, string Seller)
        {
            this.Id = Id ;
            this.itemName = itemName;
            this.Seller = Seller;
        }

       // public Item()
       // {
//
      //  }

       /* public Item(int id,string itemname, string seller,string description)
        {
            Id = id ;
            Itemname = itemname;
            Seller = seller;
            Description = Description;
        }*/
    }
}