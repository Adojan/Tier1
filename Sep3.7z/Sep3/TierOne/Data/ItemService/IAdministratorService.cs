﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TierOne.Models;

namespace TierOne.Data.ItemService
{
    public interface IAdministratorService
    {
        Task<IList<Administrator>> GetAllItemsAsync();
        Task CreateItem(Administrator item);
        Task EditItem(Administrator item);
        Task DeleteItem(Administrator id);
    
    }
}