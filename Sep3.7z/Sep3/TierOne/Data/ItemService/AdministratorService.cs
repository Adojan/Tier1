﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TierOne.Models;


namespace TierOne.Data.ItemService
{
    public class AdministratorService : IAdministratorService
    {
        public async Task<IList<Administrator>> GetAllItemsAsync()
        {
            //not done.
            HttpClient httpClient = new HttpClient();
            string uri = "https://localhost:8090/item";
            string message = await httpClient.GetStringAsync(uri);
            IList<Administrator> result = JsonSerializer.Deserialize<IList<Administrator>>(message);
            return result;
        }

        public async Task CreateItem(Administrator item)
        {
            HttpClient httpClient = new HttpClient();
            string serialized = JsonSerializer.Serialize(item);
            StringContent content = new StringContent(
                serialized,
                Encoding.UTF8,
                "application/json");
            HttpResponseMessage responseMessage =
                await httpClient.PostAsync("http://localhost:8090/items", content);
        }

        public async Task EditItem(Administrator item)
        {
            HttpClient httpClient = new HttpClient();
            string itemSerialized = JsonSerializer.Serialize(item);
            StringContent content = new StringContent(
                itemSerialized,
                Encoding.UTF8,
                "applicatiom/json");
            HttpResponseMessage responseMessage = await httpClient.PatchAsync("http://localhost:8090/items", content);
            Console.WriteLine(responseMessage.StatusCode.ToString());
        }
//not done
        public Task DeleteItem(Administrator id)
        {
            throw new NotImplementedException();
        }

        public async Task DeleteItem(int id)
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage responseMessage = await client.DeleteAsync(("http://localhost:8090/items" + id));
            Console.WriteLine(responseMessage.StatusCode.ToString());
        }
    }
}