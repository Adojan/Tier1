﻿using System.Collections.Generic;
using System.Dynamic;
using System.Threading.Tasks;
using TierOne.Models;
namespace TierOne.Data.UserService
{
  
         public interface IUserService
            {
                Task<string> RegisterUser(User user);
                Task<User> ValidateUser(User user);
        
                Task DeleteAccount(int id);
        
                Task<string> EditUser(User user);
                Task<User> GetUsers();
                Task<User> GetUserById(int id);
                
            }
    }
