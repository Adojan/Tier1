﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using TierOne.Models;

namespace TierOne.Data.UserService
{
    public class UserService : IUserService
    {
        public async Task<string> RegisterUser(User user)
        {
            HttpClient httpClient = new HttpClient();
            string userSerialized = JsonSerializer.Serialize(user);
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://localhost:8090/register"),
                Content = new StringContent(userSerialized, Encoding.UTF8, "application/json")
            };

            var response = httpClient.SendAsync(request).ConfigureAwait(false);
            var responseInfo = response.GetAwaiter().GetResult();
            string s = await responseInfo.Content.ReadAsStringAsync();
            return s;
        }

        public async Task<User> ValidateUser(User user)
        {
            HttpClient httpClient = new HttpClient();
            string userSerialized = JsonSerializer.Serialize(user);

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://localhost:8090/login"),
                Content = new StringContent(userSerialized, Encoding.UTF8, "application/json")
            };

            var response = httpClient.SendAsync(request).ConfigureAwait(false);
            var responseInfo = response.GetAwaiter().GetResult();
            string s = await responseInfo.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<User>(s);
        }
        
        public async Task DeleteAccount(int userId)
        {
            HttpClient client = new HttpClient();
            HttpResponseMessage responseMessage = await client.DeleteAsync("http://localhost:8090/delete/" + userId);
            Console.WriteLine(responseMessage.StatusCode.ToString());
        }

        public async Task<string> EditUser(User user)
        {
            HttpClient httpClient = new HttpClient();
            string accountSerialized = JsonSerializer.Serialize(user);
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri("https://localhost:8090/user"),
                Content = new StringContent(accountSerialized, Encoding.UTF8, "application/json")
            };

            var response = httpClient.SendAsync(request).ConfigureAwait(false);
            var responseInfo = response.GetAwaiter().GetResult();
            string s = await responseInfo.Content.ReadAsStringAsync();
            return s;
        }

        public async Task<User> GetUsers()
        {
            HttpClient httpClient = new HttpClient();
            string uri = "https://localhost:8090/user";
            string message = await httpClient.GetStringAsync(uri);

            Console.WriteLine("ASDASDASD" + message);

            User result = JsonSerializer.Deserialize<User>(message);
            return result;
        }

        public async Task<User> GetUserById(int id)
        {
            HttpClient httpClient = new HttpClient();
            string uri = "https://localhost:8090/user/" + id;
            string message = await httpClient.GetStringAsync(uri);
            User result = JsonSerializer.Deserialize<User>(message);
            return result;
        }
    }
}
